<!DOCTYPE html>
<html lang="en">
<head>
  <title>List User</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>List User</h2>           
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Username</th>
        <th>Password</th>
        <th>Email</th>
        <th>Role</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <tr>
        <td><?php echo e($u->username); ?></td>
        <td>
            <?php if($u->role  == 'Admin'): ?>
              *****
            <?php else: ?>
              <?php echo e($u->password); ?>

            <?php endif; ?>
        </td>
        <td><?php echo e($u->email); ?></td>
        <td><?php echo e($u->role); ?></td>
        <td>
            <?php if($u->role  == 'Admin'): ?>
              Not Allowed
            <?php else: ?>
              <form method="POST" action="<?php echo e(url('/admin/delete')); ?>/<?php echo e($u->id); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button type="submit">Delete</button>
              </form>
            <?php endif; ?>        
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </tbody>
  </table>
  <center><?php echo e($data->links()); ?></center>
</div>

</body>
</html>
